
const BarbeariaDados = {
    vendas: [
        // { tipo: "servico/produto", itemId: 1, profissionalId: 1, quantidade: 1, data: "", valor: 0 }
    ],
    produtos: [
        { id: 1, nome: "Shampoo", preco: 25, estoque: 10, descricao: "Shampoo para cabelos" },
        { id: 2, nome: "Condicionador", preco: 30, estoque: 8, descricao: "Condicionador para cabelos" }
    ],
    profissionais: [
        { id: 1, nome: "João Silva", telefone: "(11) 99999-9999", email: "joao@email.com", especialidade: "Corte Masculino" },
        { id: 2, nome: "Pedro Santos", telefone: "(11) 88888-8888", email: "pedro@email.com", especialidade: "Barba" }
    ],
    servicos: [
        { id: 1, nome: "Corte Masculino", preco: 30, descricao: "Corte tradicional masculino" },
        { id: 2, nome: "Barba", preco: 20, descricao: "Acabamento de barba" },
        { id: 3, nome: "Corte + Barba", preco: 45, descricao: "Combo corte e barba" }
    ],
    barbeiros: [
        { id: 1, nome: "João", cortes: 0 },
        { id: 2, nome: "Pedro", cortes: 0 },
        { id: 3, nome: "Miguel", cortes: 0 }
    ],
    
    agendamentos: [],
    clientes: [
        // { nome: "", telefone: "", email: "" }
    ],
    
    inicializar() {
        const dadosSalvos = localStorage.getItem('barbeariaDados');
        if (dadosSalvos) {
            const dados = JSON.parse(dadosSalvos);
            this.vendas = dados.vendas || [];
            this.produtos = dados.produtos || this.produtos;
            this.profissionais = dados.profissionais || this.profissionais;
            this.servicos = dados.servicos || this.servicos;
            this.barbeiros = dados.barbeiros || this.barbeiros;
            this.agendamentos = dados.agendamentos || [];
            this.clientes = dados.clientes || [];
        }
        this.salvarDados();
    },

    salvarDados() {
        localStorage.setItem('barbeariaDados', JSON.stringify({
            vendas: this.vendas,
            produtos: this.produtos,
            profissionais: this.profissionais,
            servicos: this.servicos,
            barbeiros: this.barbeiros,
            agendamentos: this.agendamentos,
            clientes: this.clientes
        }));
    },

    registrarCorte(barbeiroId) {
        const barbeiro = this.barbeiros.find(b => b.id === parseInt(barbeiroId));
        if (barbeiro) {
            barbeiro.cortes++;
            this.salvarDados();
        }
    },

    adicionarAgendamento(appointment) {
        this.agendamentos.push(appointment);
        if (!this.clientes.includes(appointment.clientName)) {
            this.clientes.push(appointment.clientName);
        }
        this.salvarDados();
    },

    removerAgendamento(index) {
        this.agendamentos.splice(index, 1);
        this.salvarDados();
    },

    obterAgendamentos() {
        return this.agendamentos;
    },

    obterClientes() {
        return this.clientes;
    },

    adicionarCliente(cliente) {
        this.clientes.push(cliente);
        this.salvarDados();
    },

    removerCliente(index) {
        this.clientes.splice(index, 1);
        this.salvarDados();
    },

    adicionarServico(servico) {
        const id = this.servicos.length > 0 ? Math.max(...this.servicos.map(s => s.id)) + 1 : 1;
        this.servicos.push({ ...servico, id });
        this.salvarDados();
    },

    removerServico(id) {
        this.servicos = this.servicos.filter(s => s.id !== id);
        this.salvarDados();
    },

    obterServicos() {
        return this.servicos;
    },

    adicionarProfissional(profissional) {
        const id = this.profissionais.length > 0 ? Math.max(...this.profissionais.map(p => p.id)) + 1 : 1;
        this.profissionais.push({ ...profissional, id });
        this.salvarDados();
    },

    removerProfissional(id) {
        this.profissionais = this.profissionais.filter(p => p.id !== id);
        this.salvarDados();
    },

    obterProfissionais() {
        return this.profissionais;
    },

    adicionarProduto(produto) {
        const id = this.produtos.length > 0 ? Math.max(...this.produtos.map(p => p.id)) + 1 : 1;
        this.produtos.push({ ...produto, id });
        this.salvarDados();
    },

    removerProduto(id) {
        this.produtos = this.produtos.filter(p => p.id !== id);
        this.salvarDados();
    },

    obterProdutos() {
        return this.produtos;
    },

    adicionarVenda(venda) {
        this.vendas.push({
            ...venda,
            data: new Date().toISOString(),
            id: this.vendas.length + 1
        });
        this.salvarDados();
    },

    obterVendas() {
        return this.vendas;
    },

    obterEstatisticas() {
        return this.barbeiros.map(barbeiro => ({
            id: barbeiro.id,
            nome: barbeiro.nome,
            totalCortes: barbeiro.cortes
        }));
    },

    calcularReceitaMensal() {
        const hoje = new Date();
        const primeiroDiaMes = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
        const agendamentosMes = this.agendamentos.filter(a => {
            const dataAgendamento = new Date(a.date);
            return dataAgendamento >= primeiroDiaMes;
        });

        const precos = {
            'corte': 30,
            'barba': 20,
            'corte-barba': 45
        };

        return agendamentosMes.reduce((total, agendamento) => {
            return total + (precos[agendamento.service] || 0);
        }, 0);
    }
};
