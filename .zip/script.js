
document.addEventListener('DOMContentLoaded', () => {
    // Inicializar dados
    BarbeariaDados.inicializar();

    // Navegação
    const menuItems = document.querySelectorAll('.sidebar nav ul li');
    menuItems.forEach(item => {
        item.addEventListener('click', () => {
            const page = item.getAttribute('data-page');
            document.querySelector('.page.active').classList.remove('active');
            document.querySelector(`#page-${page}`).classList.add('active');
            document.querySelector('.sidebar li.active').classList.remove('active');
            item.classList.add('active');
        });
    });

    // Preencher select de barbeiros
    const barberSelect = document.getElementById('barber');
    BarbeariaDados.barbeiros.forEach(barbeiro => {
        const option = document.createElement('option');
        option.value = barbeiro.id;
        option.textContent = barbeiro.nome;
        barberSelect.appendChild(option);
    });

    // Formulário de agendamento
    const form = document.getElementById('appointment-form');
    if (form) {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const appointment = {
                clientName: document.getElementById('client-name').value,
                date: document.getElementById('date').value,
                time: document.getElementById('time').value,
                service: document.getElementById('service').value,
                barberId: document.getElementById('barber').value
            };
            BarbeariaDados.adicionarAgendamento(appointment);
            atualizarDashboard();
            
            // Formatar mensagem para WhatsApp
            const mensagem = `Olá ${appointment.clientName}! Seu agendamento foi confirmado:\n\nData: ${appointment.date}\nHorário: ${appointment.time}\nServiço: ${appointment.service}\n\nAguardamos você!`;
            const mensagemFormatada = encodeURIComponent(mensagem);
            
            // Encontrar telefone do cliente
            const cliente = BarbeariaDados.obterClientes().find(c => c.nome === appointment.clientName);
            if (cliente && cliente.telefone) {
                const telefone = cliente.telefone.replace(/\D/g, ''); // Remove caracteres não numéricos
                window.open(`https://wa.me/55${telefone}?text=${mensagemFormatada}`, '_blank');
            }
            
            form.reset();
        });
    }

    function atualizarDashboard() {
        const vendas = BarbeariaDados.obterVendas();
        const profissionais = BarbeariaDados.obterProfissionais();
        
        // Calcular estatísticas
        const estatisticasPorBarbeiro = profissionais.map(profissional => {
            const vendasBarbeiro = vendas.filter(v => v.profissionalId === profissional.id);
            const totalCortes = vendasBarbeiro.filter(v => v.tipo === 'servico').length;
            const totalReceita = vendasBarbeiro.reduce((total, venda) => total + venda.valor, 0);
            
            return {
                nome: profissional.nome,
                totalCortes,
                totalReceita
            };
        });

        // Atualizar cards
        const totalCortes = estatisticasPorBarbeiro.reduce((total, barb) => total + barb.totalCortes, 0);
        const totalReceita = estatisticasPorBarbeiro.reduce((total, barb) => total + barb.totalReceita, 0);
        
        document.getElementById('total-haircuts').textContent = totalCortes;
        document.getElementById('total-clients').textContent = BarbeariaDados.obterClientes().length;
        document.getElementById('total-revenue').textContent = `R$ ${totalReceita.toFixed(2)}`;

        // Destruir gráficos anteriores se existirem
        const oldPerformanceChart = Chart.getChart('barbers-performance-chart');
        if (oldPerformanceChart) {
            oldPerformanceChart.destroy();
        }
        const oldRevenueChart = Chart.getChart('revenue-by-barber-chart');
        if (oldRevenueChart) {
            oldRevenueChart.destroy();
        }

        // Gráfico de desempenho (cortes)
        const performanceChart = new Chart(document.getElementById('barbers-performance-chart'), {
            type: 'bar',
            data: {
                labels: estatisticasPorBarbeiro.map(b => b.nome),
                datasets: [{
                    label: 'Total de Cortes',
                    data: estatisticasPorBarbeiro.map(b => b.totalCortes),
                    backgroundColor: '#9b59b6'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Cortes por Profissional',
                        color: '#fff'
                    },
                    legend: {
                        labels: {
                            color: '#fff'
                        }
                    }
                },
                scales: {
                    y: {
                        ticks: {
                            color: '#fff'
                        }
                    },
                    x: {
                        ticks: {
                            color: '#fff'
                        }
                    }
                }
            }
        });

        // Gráfico de receita por barbeiro
        const revenueChart = new Chart(document.getElementById('revenue-by-barber-chart'), {
            type: 'pie',
            data: {
                labels: estatisticasPorBarbeiro.map(b => b.nome),
                datasets: [{
                    data: estatisticasPorBarbeiro.map(b => b.totalReceita),
                    backgroundColor: ['#9b59b6', '#3498db', '#e74c3c', '#2ecc71']
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Receita por Profissional',
                        color: '#fff'
                    },
                    legend: {
                        labels: {
                            color: '#fff'
                        }
                    }
                }
            }
        });

        const appointmentsList = document.getElementById('appointments-list');
        if (appointmentsList) {
            const agendamentos = BarbeariaDados.obterAgendamentos();
            appointmentsList.innerHTML = `
                <h2>Agendamentos</h2>
                ${agendamentos.map((appointment, index) => `
                    <div class="appointment-card">
                        <div>
                            <p><strong>Cliente:</strong> ${appointment.clientName}</p>
                            <p><strong>Data:</strong> ${appointment.date}</p>
                            <p><strong>Hora:</strong> ${appointment.time}</p>
                            <p><strong>Serviço:</strong> ${appointment.service}</p>
                        </div>
                        <button onclick="deleteAppointment(${index})">Cancelar</button>
                    </div>
                `).join('')}
            `;
        }
    }

    window.registrarCorte = (barbeiroId) => {
        BarbeariaDados.registrarCorte(barbeiroId);
        atualizarDashboard();
    };

    window.deleteAppointment = (index) => {
        BarbeariaDados.removerAgendamento(index);
        atualizarDashboard();
    };

    // Formulário de cliente
    const clientForm = document.getElementById('client-form');
    if (clientForm) {
        clientForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const telefone = document.getElementById('new-client-phone').value;
            const telefoneRegex = /^\+1 \(\d{3}\) \d{3}-\d{4}$/;
            
            if (!telefoneRegex.test(telefone)) {
                alert('Por favor, insira o telefone no formato: +1 (508) 939-1881');
                return;
            }

            const cliente = {
                nome: document.getElementById('new-client-name').value,
                telefone: telefone,
                email: document.getElementById('new-client-email').value
            };
            BarbeariaDados.adicionarCliente(cliente);
            atualizarListaClientes();
            clientForm.reset();
        });
    }

    function atualizarListaClientes() {
        const clientsList = document.getElementById('clients-list');
        if (clientsList) {
            const clientes = BarbeariaDados.obterClientes();
            clientsList.innerHTML = `
                <h2>Clientes Cadastrados</h2>
                ${clientes.map((cliente, index) => `
                    <div class="client-card">
                        <div>
                            <p><strong>Nome:</strong> ${cliente.nome}</p>
                            <p><strong>Telefone:</strong> ${cliente.telefone}</p>
                            <p><strong>Email:</strong> ${cliente.email}</p>
                        </div>
                        <button onclick="removerCliente(${index})">Remover</button>
                    </div>
                `).join('')}
            `;
        }
    }

    window.removerCliente = (index) => {
        BarbeariaDados.removerCliente(index);
        atualizarListaClientes();
    };

    // Inicializar dashboard e lista de clientes
    atualizarDashboard();
    atualizarListaClientes();
    atualizarListaServicos();

    // Formulário de serviço
    const serviceForm = document.getElementById('service-form');
    if (serviceForm) {
        serviceForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const servico = {
                nome: document.getElementById('service-name').value,
                preco: parseFloat(document.getElementById('service-price').value),
                descricao: document.getElementById('service-description').value
            };
            BarbeariaDados.adicionarServico(servico);
            atualizarListaServicos();
            serviceForm.reset();
        });
    }

    function atualizarListaServicos() {
        const servicesList = document.getElementById('services-list');
        if (servicesList) {
            const servicos = BarbeariaDados.obterServicos();
            servicesList.innerHTML = `
                <h2>Serviços Cadastrados</h2>
                ${servicos.map(servico => `
                    <div class="service-card">
                        <div>
                            <p><strong>Nome:</strong> ${servico.nome}</p>
                            <p><strong>Preço:</strong> R$ ${servico.preco.toFixed(2)}</p>
                            <p><strong>Descrição:</strong> ${servico.descricao}</p>
                        </div>
                        <button onclick="removerServico(${servico.id})">Remover</button>
                    </div>
                `).join('')}
            `;
        }
    }

    window.removerServico = (id) => {
        BarbeariaDados.removerServico(id);
        atualizarListaServicos();
    };

    // Formulário de profissional
    const professionalForm = document.getElementById('professional-form');
    if (professionalForm) {
        professionalForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const profissional = {
                nome: document.getElementById('professional-name').value,
                telefone: document.getElementById('professional-phone').value,
                email: document.getElementById('professional-email').value,
                especialidade: document.getElementById('professional-specialty').value
            };
            BarbeariaDados.adicionarProfissional(profissional);
            atualizarListaProfissionais();
            professionalForm.reset();
        });
    }

    function atualizarListaProfissionais() {
        const professionalsList = document.getElementById('professionals-list');
        if (professionalsList) {
            const profissionais = BarbeariaDados.obterProfissionais();
            professionalsList.innerHTML = `
                <h2>Profissionais Cadastrados</h2>
                ${profissionais.map(profissional => `
                    <div class="professional-card">
                        <div>
                            <p><strong>Nome:</strong> ${profissional.nome}</p>
                            <p><strong>Telefone:</strong> ${profissional.telefone}</p>
                            <p><strong>Email:</strong> ${profissional.email}</p>
                            <p><strong>Especialidade:</strong> ${profissional.especialidade}</p>
                        </div>
                        <button onclick="removerProfissional(${profissional.id})">Remover</button>
                    </div>
                `).join('')}
            `;
        }
    }

    window.removerProfissional = (id) => {
        BarbeariaDados.removerProfissional(id);
        atualizarListaProfissionais();
    };

    // Inicializar lista de profissionais
    atualizarListaProfissionais();
    atualizarListaProdutos();

    // Formulário de produto
    const productForm = document.getElementById('product-form');
    if (productForm) {
        productForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const produto = {
                nome: document.getElementById('product-name').value,
                preco: parseFloat(document.getElementById('product-price').value),
                estoque: parseInt(document.getElementById('product-stock').value),
                descricao: document.getElementById('product-description').value
            };
            BarbeariaDados.adicionarProduto(produto);
            atualizarListaProdutos();
            productForm.reset();
        });
    }

    function atualizarListaProdutos() {
        const productsList = document.getElementById('products-list');
        if (productsList) {
            const produtos = BarbeariaDados.obterProdutos();
            productsList.innerHTML = `
                <h2>Produtos Cadastrados</h2>
                ${produtos.map(produto => `
                    <div class="product-card">
                        <div>
                            <p><strong>Nome:</strong> ${produto.nome}</p>
                            <p><strong>Preço:</strong> R$ ${produto.preco.toFixed(2)}</p>
                            <p><strong>Estoque:</strong> ${produto.estoque}</p>
                            <p><strong>Descrição:</strong> ${produto.descricao}</p>
                        </div>
                        <button onclick="removerProduto(${produto.id})">Remover</button>
                    </div>
                `).join('')}
            `;
        }
    }

    window.removerProduto = (id) => {
        BarbeariaDados.removerProduto(id);
        atualizarListaProdutos();
    };

    // Controle do formulário de vendas
    let selectedItems = [];
    let totalVenda = 0;

    // Preencher selects de vendas
    const saleServiceSelect = document.getElementById('sale-service');
    const saleProductSelect = document.getElementById('sale-product');
    const saleProfessionalSelect = document.getElementById('sale-professional');
    const selectedItemsDiv = document.getElementById('selected-items');
    const saleTotalSpan = document.getElementById('sale-total');

    function atualizarTotal() {
        totalVenda = selectedItems.reduce((total, item) => total + item.valor, 0);
        saleTotalSpan.textContent = totalVenda.toFixed(2);
    }

    function atualizarItensSelectionados() {
        selectedItemsDiv.innerHTML = selectedItems.map((item, index) => `
            <div class="selected-item">
                <p>${item.tipo === 'servico' ? 'Serviço' : 'Produto'}: ${item.nome} - 
                   Qtd: ${item.quantidade} - R$ ${item.valor.toFixed(2)}</p>
                <button type="button" onclick="removerItem(${index})">Remover</button>
            </div>
        `).join('');
        atualizarTotal();
    }

    window.removerItem = (index) => {
        selectedItems.splice(index, 1);
        atualizarItensSelectionados();
    };

    if (saleServiceSelect) {
        BarbeariaDados.obterServicos().forEach(servico => {
            const option = document.createElement('option');
            option.value = servico.id;
            option.textContent = `${servico.nome} - R$ ${servico.preco.toFixed(2)}`;
            saleServiceSelect.appendChild(option);
        });
    }

    if (saleProductSelect) {
        BarbeariaDados.obterProdutos().forEach(produto => {
            const option = document.createElement('option');
            option.value = produto.id;
            option.textContent = `${produto.nome} - R$ ${produto.preco.toFixed(2)}`;
            saleProductSelect.appendChild(option);
        });
    }

    if (saleProfessionalSelect) {
        BarbeariaDados.obterProfissionais().forEach(profissional => {
            const option = document.createElement('option');
            option.value = profissional.id;
            option.textContent = profissional.nome;
            saleProfessionalSelect.appendChild(option);
        });
    }

    // Adicionar Serviço
    document.getElementById('add-service').addEventListener('click', () => {
        const servicoId = parseInt(saleServiceSelect.value);
        if (servicoId) {
            const servico = BarbeariaDados.obterServicos().find(s => s.id === servicoId);
            selectedItems.push({
                tipo: 'servico',
                id: servicoId,
                nome: servico.nome,
                quantidade: 1,
                valor: servico.preco
            });
            atualizarItensSelectionados();
            saleServiceSelect.value = '';
        }
    });

    // Adicionar Produto
    document.getElementById('add-product').addEventListener('click', () => {
        const produtoId = parseInt(saleProductSelect.value);
        const quantidade = parseInt(document.getElementById('sale-quantity').value);
        if (produtoId && quantidade > 0) {
            const produto = BarbeariaDados.obterProdutos().find(p => p.id === produtoId);
            selectedItems.push({
                tipo: 'produto',
                id: produtoId,
                nome: produto.nome,
                quantidade: quantidade,
                valor: produto.preco * quantidade
            });
            atualizarItensSelectionados();
            saleProductSelect.value = '';
            document.getElementById('sale-quantity').value = 1;
        }
    });

    // Formulário de vendas
    const salesForm = document.getElementById('sales-form');
    if (salesForm) {
        salesForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const profissionalId = parseInt(document.getElementById('sale-professional').value);
            
            if (!profissionalId || selectedItems.length === 0) {
                alert('Selecione um profissional e pelo menos um item para a venda');
                return;
            }

            // Registrar cada item como uma venda separada
            selectedItems.forEach(item => {
                const venda = {
                    tipo: item.tipo,
                    itemId: item.id,
                    profissionalId: profissionalId,
                    quantidade: item.quantidade,
                    valor: item.valor
                };
                
                if (item.tipo === 'servico') {
                    BarbeariaDados.registrarCorte(profissionalId);
                }
                
                BarbeariaDados.adicionarVenda(venda);
            });

            selectedItems = [];
            atualizarItensSelectionados();
            atualizarListaVendas();
            salesForm.reset();
            atualizarDashboard();
        });
    }

    function atualizarListaVendas() {
        const salesList = document.getElementById('sales-list');
        if (salesList) {
            const vendas = BarbeariaDados.obterVendas();
            salesList.innerHTML = `
                <h2>Vendas Realizadas</h2>
                ${vendas.map(venda => {
                    const profissional = BarbeariaDados.obterProfissionais().find(p => p.id === venda.profissionalId);
                    const item = venda.tipo === 'servico' 
                        ? BarbeariaDados.obterServicos().find(s => s.id === venda.itemId)
                        : BarbeariaDados.obterProdutos().find(p => p.id === venda.itemId);
                    
                    return `
                        <div class="sale-card">
                            <div>
                                <p><strong>Tipo:</strong> ${venda.tipo === 'servico' ? 'Serviço' : 'Produto'}</p>
                                <p><strong>Item:</strong> ${item.nome}</p>
                                <p><strong>Profissional:</strong> ${profissional.nome}</p>
                                <p><strong>Quantidade:</strong> ${venda.quantidade}</p>
                                <p><strong>Valor:</strong> R$ ${venda.valor.toFixed(2)}</p>
                                <p><strong>Data:</strong> ${new Date(venda.data).toLocaleString()}</p>
                            </div>
                        </div>
                    `;
                }).join('')}
            `;
        }
    }

    // Funções do Financeiro
    function atualizarFinanceiro() {
        const vendas = BarbeariaDados.obterVendas();
        const hoje = new Date().toISOString().split('T')[0];
        const primeiroDiaMes = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString();

        // Calcular totais
        const totais = vendas.reduce((acc, venda) => {
            const dataVenda = venda.data.split('T')[0];
            if (dataVenda === hoje) {
                acc.hoje += venda.valor;
            }
            if (venda.data >= primeiroDiaMes) {
                acc.mes += venda.valor;
            }
            acc.total += venda.valor;
            return acc;
        }, { hoje: 0, mes: 0, total: 0 });

        // Atualizar cards
        document.getElementById('today-sales').textContent = `R$ ${totais.hoje.toFixed(2)}`;
        document.getElementById('month-sales').textContent = `R$ ${totais.mes.toFixed(2)}`;
        document.getElementById('total-sales').textContent = `R$ ${totais.total.toFixed(2)}`;

        // Preparar dados para os gráficos
        const ultimosSeteDias = [...Array(7)].map((_, i) => {
            const data = new Date();
            data.setDate(data.getDate() - i);
            return data.toISOString().split('T')[0];
        }).reverse();

        const vendasPorDia = ultimosSeteDias.map(data => ({
            data,
            valor: vendas
                .filter(v => v.data.split('T')[0] === data)
                .reduce((sum, v) => sum + v.valor, 0)
        }));

        // Ranking de barbeiros
        const vendasPorBarbeiro = vendas.reduce((acc, venda) => {
            if (!acc[venda.profissionalId]) {
                acc[venda.profissionalId] = { total: 0, quantidade: 0 };
            }
            acc[venda.profissionalId].total += venda.valor;
            acc[venda.profissionalId].quantidade += 1;
            return acc;
        }, {});

        const rankingBarbeiros = Object.entries(vendasPorBarbeiro)
            .map(([id, dados]) => ({
                profissional: BarbeariaDados.obterProfissionais().find(p => p.id === parseInt(id)),
                ...dados
            }))
            .sort((a, b) => b.total - a.total);

        // Atualizar ranking
        const rankingHTML = rankingBarbeiros
            .map((item, index) => `
                <div class="ranking-item">
                    <span class="ranking-position">#${index + 1}</span>
                    <span>${item.profissional.nome}</span>
                    <span>R$ ${item.total.toFixed(2)}</span>
                    <span>${item.quantidade} vendas</span>
                </div>
            `)
            .join('');
        document.getElementById('barbers-ranking').innerHTML = rankingHTML;

        // Atualizar gráfico de vendas
        const salesChart = new Chart(document.getElementById('sales-chart'), {
            type: 'line',
            data: {
                labels: vendasPorDia.map(v => v.data),
                datasets: [{
                    label: 'Vendas por Dia',
                    data: vendasPorDia.map(v => v.valor),
                    borderColor: '#9b59b6',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Vendas dos Últimos 7 Dias'
                    }
                }
            }
        });

        // Atualizar gráfico de barbeiros
        const barbersChart = new Chart(document.getElementById('barbers-chart'), {
            type: 'bar',
            data: {
                labels: rankingBarbeiros.map(b => b.profissional.nome),
                datasets: [{
                    label: 'Total de Vendas',
                    data: rankingBarbeiros.map(b => b.total),
                    backgroundColor: '#9b59b6'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Vendas por Profissional'
                    }
                }
            }
        });

        // Atualizar lista de vendas
        const salesList = document.getElementById('financial-sales-list');
        salesList.innerHTML = vendas.reverse().map(venda => {
            const profissional = BarbeariaDados.obterProfissionais().find(p => p.id === venda.profissionalId);
            const item = venda.tipo === 'servico'
                ? BarbeariaDados.obterServicos().find(s => s.id === venda.itemId)
                : BarbeariaDados.obterProdutos().find(p => p.id === venda.itemId);
            
            return `
                <div class="sale-card">
                    <div>
                        <p><strong>Tipo:</strong> ${venda.tipo === 'servico' ? 'Serviço' : 'Produto'}</p>
                        <p><strong>Item:</strong> ${item.nome}</p>
                        <p><strong>Profissional:</strong> ${profissional.nome}</p>
                        <p><strong>Quantidade:</strong> ${venda.quantidade}</p>
                        <p><strong>Valor:</strong> R$ ${venda.valor.toFixed(2)}</p>
                        <p><strong>Data:</strong> ${new Date(venda.data).toLocaleString()}</p>
                    </div>
                </div>
            `;
        }).join('');
    }

    // Inicializar lista de vendas e financeiro
    atualizarListaVendas();
    atualizarFinanceiro();
});
